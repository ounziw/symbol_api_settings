<?php
/**
 * Plugin Name: symbol api
 * Version: 0.7.1
 * License: GPL ver.2 or later
 */

require dirname( __FILE__ ) . '/http.php';
require dirname( __FILE__ ) . '/mosaics.php';
require dirname( __FILE__ ) . '/settings-api.php';
require dirname( __FILE__ ) . '/shortcode.php';
require dirname( __FILE__ ) . '/validate.php';

